import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class View extends JFrame implements KeyListener {

	/*
	 * This is a text render originally made by Leonardo.
	 * Used by Vivian to make Text Tic-Tac-Toe.
	*/
	
	private Thread mainThread;
	private JTextArea display = new JTextArea();
	private final int SCRNWIDTH = 101, SCRNHEIGHT = 24;
	private char[][] screen = new char[SCRNWIDTH][SCRNHEIGHT];
	private boolean running = false, waiting = false;
	
	private char[][] board = new char[3][3];
	private char playOne = 'X', playTwo = 'O';
	private char currTurn = playOne, prevTurn;
	private boolean turnX, turnY = true;
	private int playerX, playerY;
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			View main = new View();
			main.setVisible(true);
		});
	}
	
	public View() throws HeadlessException {
		setSize(new Dimension(425, 400));
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Text Game Test");
//		setVisible(true);
		
		display.setFont(new Font("Courier New", Font.PLAIN, 16));
		display.setBackground(Color.black);
		display.setForeground(Color.green);
		display.addKeyListener(this);
		add(display);
		display.requestFocus();
		createBoard();
		
		running = true;
		mainThread = new Thread(() -> {
			while(running) {
				//TODO Implement false check
				render();
				display.setText(convertScreenToText());
//				System.out.println("X: " + playerX + " | Y: " + playerY);
//				System.out.println("TurnX: " + turnX + " | TurnY: " + turnY);
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
		});
		mainThread.start();
	}
	
	public void createBoard() {
		for(int y = 0; y < 3; y++) {
			for(int x = 0; x < 3; x++) {
				board[x][y] = '.';
			}
		}
	}
	
	int textX = 13;
	public void renderBoardToScreen() {
//		for(int y = 0; y < 3; y++) {
//			for(int x = 0; x < 3; x++) {
//				print(x + 1, y + 1, "" + board[x][y] + "");
//			}
//		}
		print(textX, 6, "  |̲ ̲1̲ ̲|̲ ̲2̲ ̲|̲ ̲3̲ |");
		print(textX, 7, "1 | " + board[0][0] + " | " + board[1][0] + " | " + board[2][0] + " |");
		print(textX, 8, "--|---|---|---|");
		print(textX, 9, "2 | " + board[0][1] + " | " + board[1][1] + " | " + board[2][1] + " |");
		print(textX, 10, "--|---|---|---|");
		print(textX, 11, "3 | " + board[0][2] + " | " + board[1][2] + " | " + board[2][2] + " |");
		print(textX, 12, "--|---|---|---|");
	}
	
	public void renderGuiBox() {
		print(29, 5, "#=======#");
		print(40, 6, "|       |");
		print(29, 7, "#=======#");
//		for(int i = 0; i < 1; i++) {
//			if(i == 0) {
//				print(40, 6, "|       |");
//			} else {
//				print(29, 6 + i, "|       |");
//			} 
//		}
		addPlayerInfo();
	}
	
	public void addPlayerInfo() {
		print(41, 6, "Turn: " + currTurn);
	}
	
	private String convertScreenToText() {
		StringBuilder sb = new StringBuilder();
		for (int y = 0; y < SCRNHEIGHT; y++) {
			for(int x = 0; x < SCRNWIDTH; x++) {
				sb.append(screen[x][y]);
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	
	private void print(int x, int y, String c) {
		for (int col = 0; col < c.length(); col++) {
			screen[x + col][y] = c.charAt(col);
		}
	}
	
	private void clear() {
		for(int y = 0; y < SCRNHEIGHT; y++) {
			for(int x = 0; x < SCRNWIDTH; x++) {
				screen[x][y] = ' ';
			}
		}
	}
	
	public void render() {
		clear();
		print(22, 1, "Reset the board: R");
		print(2, 17, "Y -> X");
		print(10, 18, "Thanks for Playing! :)");
		renderBoardToScreen();
		renderGuiBox();
		if(waiting) {
			renderWinnerBox();
		}
		//TODO Implement other methods
	}
	
	public void playerTurnX() {
		turnY = true;
		setPlayerPiece(playerX, playerY);
	}
	
	public void playerTurnY() {
		turnX = true;
	}
	
	public void setPlayerPiece(int x, int y) {
		if(board[x][y] == '.') {
			board[x][y] = currTurn;
			System.out.println("Option 1");
			playerX = 0;
			playerY = 0;
			switchTurn();
		}
	}
	
	public void switchTurn() {
		if(currTurn == playOne) {
			winCheck();
			prevTurn = currTurn;
			currTurn = playTwo;
		} else if(currTurn == playTwo) {
			winCheck();
			prevTurn = currTurn;
			currTurn = playOne;
		}
	}
	
	public void winCheck() {
		//Horizontal Check
		if(board[0][0] == currTurn && board[1][0] == currTurn && board[2][0] == currTurn) {
//			System.out.println("This worked");
			winner();
		} else if(board[0][1] == currTurn && board[1][1] == currTurn && board[2][1] == currTurn) {
//			System.out.println("This worked");
			winner();
		} else if(board[0][2] == currTurn && board[1][2] == currTurn && board[2][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		}
		//Vertical Check
		if(board[0][0] == currTurn && board[0][1] == currTurn && board[0][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		} else if(board[1][0] == currTurn && board[1][1] == currTurn && board[1][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		} else if(board[2][0] == currTurn && board[2][1] == currTurn && board[2][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		}
		//Cross Check
		if(board[0][0] == currTurn && board[1][1] == currTurn && board[2][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		} else if(board[2][0] == currTurn && board[1][1] == currTurn && board[0][2] == currTurn) {
//			System.out.println("This worked");
			winner();
		}
	}
	
	public void winner() {
		waiting = true;
	}
	
	public void renderWinnerBox() {
		print(12, 7, "#=================#");
		print(12, 13, "#=================#");
		for(int i = 0; i < 5; i++) {
			print(12, 8 + i, "|                 |");
		}
		addWinnerInfo();
	}
	
	public void addWinnerInfo() {
		print(13, 9, "Winning Player: " + prevTurn);
		print(14, 11, "Congratuations!");
	}
	
	public void resetGame() {
		waiting = false;
		for(int y = 0; y < 3; y++) {
			for(int x = 0; x < 3; x++) {
				board[x][y] = '.';
			}
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
//		System.out.println("Get KeyCode: " +  e.getKeyCode());
		if(!waiting) {
			if(turnX) {
				switch(e.getKeyCode()) {
				case 49: playerX = 0; turnX = false; playerTurnX(); break;
				case 50: playerX = 1; turnX = false; playerTurnX(); break;
				case 51: playerX = 2; turnX = false; playerTurnX(); break;
				} 
			}else if(turnY) {
				switch(e.getKeyCode()) {
				case 49: playerY = 0; turnY = false; playerTurnY(); break;
				case 50: playerY = 1; turnY = false; playerTurnY(); break;
				case 51: playerY = 2; turnY = false; playerTurnY(); break;
				}
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_R) {
			resetGame();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
